import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;

public class ReturnWindow extends JFrame {

    Database db = new Database();
    DefaultTableModel model;

    public ReturnWindow() {
        setTitle("Return Book");
        setSize(600, 400);
        setLayout(null);

        model = new DefaultTableModel(
                new String[]{"Loan ID", "Book", "Reader", "Date Loan"}, 0
        );

        JTable table = new JTable(model);
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 20, 550, 250);
        add(pane);

        JButton returnBtn = new JButton("Return Book");
        returnBtn.setBounds(200, 300, 150, 30);
        add(returnBtn);

        loadLoans();

        returnBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Выберите запись!");
                return;
            }

            int loanId = Integer.parseInt(
                    table.getValueAt(row, 0).toString()
            );

            int fine = db.returnBook(loanId);

            JOptionPane.showMessageDialog(
                    this,
                    "Книга успешно возвращена!\nШтраф: " + fine + " тг"
            );

            loadLoans();
        });

        setVisible(true);
    }

    private void loadLoans() {
        model.setRowCount(0);

        try {
            ResultSet rs = db.getLoans();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("name"),
                        rs.getString("date_loan")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
