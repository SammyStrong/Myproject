import javax.swing.*;
import java.sql.ResultSet;

public class LoanWindow extends JFrame {

    Database db = new Database();

    public LoanWindow() {
        setTitle("Loan Book");
        setSize(400, 300);
        setLayout(null);

        JLabel l1 = new JLabel("Book:");
        l1.setBounds(20, 20, 80, 25);
        add(l1);

        JComboBox<String> bookBox = new JComboBox<>();
        bookBox.setBounds(100, 20, 200, 25);
        add(bookBox);

        JLabel l2 = new JLabel("Reader:");
        l2.setBounds(20, 60, 80, 25);
        add(l2);

        JComboBox<String> readerBox = new JComboBox<>();
        readerBox.setBounds(100, 60, 200, 25);
        add(readerBox);

        JButton issueBtn = new JButton("Issue");
        issueBtn.setBounds(140, 120, 100, 30);
        add(issueBtn);

        loadBooks(bookBox);
        loadReaders(readerBox);

        issueBtn.addActionListener(e -> {
            try {
                String b = bookBox.getSelectedItem().toString();
                int bookId = Integer.parseInt(b.split("\\.")[0]);

                String r = readerBox.getSelectedItem().toString();
                int readerId = Integer.parseInt(r.split("\\.")[0]);

                // === IMPORTANT: CHECK IF BOOK IS ALREADY LOANED ===
                if (!db.isBookAvailable(bookId)) {
                    JOptionPane.showMessageDialog(this,
                            "Эта книга уже выдана! Сначала её должны вернуть.",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                db.loanBook(bookId, readerId);
                JOptionPane.showMessageDialog(this, "Книга успешно выдана!");

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        setVisible(true);
    }

    private void loadBooks(JComboBox<String> box) {
        try {
            ResultSet rs = db.getBooks();
            while (rs.next()) {
                box.addItem(rs.getInt("id") + ". " + rs.getString("title"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadReaders(JComboBox<String> box) {
        try {
            ResultSet rs = db.getReaders();
            while (rs.next()) {
                box.addItem(rs.getInt("id") + ". " + rs.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
