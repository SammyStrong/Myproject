import javax.swing.*;

public class MainMenu extends JFrame {

    public MainMenu() {
        setTitle("Library System");
        setSize(300, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new java.awt.GridLayout(5, 1));

        JButton b1 = new JButton("Books");
        JButton b2 = new JButton("Readers");
        JButton b3 = new JButton("Loan Book");
        JButton b4 = new JButton("Return Book");
        JButton b5 = new JButton("Exit");

        add(b1); add(b2); add(b3); add(b4); add(b5);

        b1.addActionListener(e -> new BookWindow());
        b2.addActionListener(e -> new ReaderWindow());
        b3.addActionListener(e -> new LoanWindow());
        b4.addActionListener(e -> new ReturnWindow());
        b5.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    public static void main(String[] args) {
        new MainMenu();
    }
}
