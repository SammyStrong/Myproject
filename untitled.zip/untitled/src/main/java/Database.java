import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Database {

    private static Connection conn;

    static {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:library.db");
            init();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void init() throws SQLException {
        Statement st = conn.createStatement();

        st.execute("""
            CREATE TABLE IF NOT EXISTS books(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL
            )
        """);

        st.execute("""
            CREATE TABLE IF NOT EXISTS readers(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            )
        """);

        st.execute("""
            CREATE TABLE IF NOT EXISTS loans(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER,
                reader_id INTEGER,
                date_loan TEXT,
                FOREIGN KEY(book_id) REFERENCES books(id),
                FOREIGN KEY(reader_id) REFERENCES readers(id)
            )
        """);
    }

    public void addBook(String title, String author) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO books(title, author) VALUES(?, ?)"
            );
            ps.setString(1, title);
            ps.setString(2, author);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public ResultSet getBooks() {
        try {
            Statement st = conn.createStatement();
            return st.executeQuery("SELECT * FROM books");
        } catch (Exception e) { return null; }
    }

    public void deleteBook(int id) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM books WHERE id=?"
            );
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void addReader(String name) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO readers(name) VALUES(?)"
            );
            ps.setString(1, name);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public ResultSet getReaders() {
        try {
            Statement st = conn.createStatement();
            return st.executeQuery("SELECT * FROM readers");
        } catch (Exception e) { return null; }
    }

    public void deleteReader(int id) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM readers WHERE id=?"
            );
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public boolean isBookAvailable(int bookId) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) AS cnt FROM loans WHERE book_id=?"
            );
            ps.setInt(1, bookId);
            ResultSet rs = ps.executeQuery();
            return rs.getInt("cnt") == 0;
        } catch (Exception e) { return false; }
    }

    public void loanBook(int bookId, int readerId) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO loans(book_id, reader_id, date_loan) VALUES(?, ?, ?)"
            );
            ps.setInt(1, bookId);
            ps.setInt(2, readerId);
            ps.setString(3, LocalDate.now().toString());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public ResultSet getLoans() {
        try {
            Statement st = conn.createStatement();
            return st.executeQuery("""
            SELECT loans.id, books.title, readers.name, loans.date_loan
            FROM loans
            JOIN books ON books.id = loans.book_id
            JOIN readers ON readers.id = loans.reader_id
        """);
        } catch (Exception e) { return null; }
    }

    public int returnBook(int loanId) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT date_loan FROM loans WHERE id=?"
            );
            ps.setInt(1, loanId);
            ResultSet rs = ps.executeQuery();

            LocalDate dateLoan = LocalDate.parse(rs.getString("date_loan"));
            long days = ChronoUnit.DAYS.between(dateLoan, LocalDate.now());

            ps = conn.prepareStatement("DELETE FROM loans WHERE id=?");
            ps.setInt(1, loanId);
            ps.executeUpdate();

            if (days <= 7) return 0;          // 7 күн ішінде → штраф жоқ
            return (int) ((days - 7) * 500);  // әр күн → 500 теңге

        } catch (Exception e) { e.printStackTrace(); return 0; }
    }
}
