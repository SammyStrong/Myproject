import java.io.*;
import java.util.*;

public class LibraryApp {

    // ====== МОДЕЛЬ КЛАСТАРЫ ======
    static class Book {
        int id;
        String title;

        Book(int id, String title) {
            this.id = id;
            this.title = title;
        }
    }

    static class Reader {
        int id;
        String name;

        Reader(int id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    static class Loan {
        int bookId;
        int readerId;
        int daysLate;

        Loan(int bookId, int readerId, int daysLate) {
            this.bookId = bookId;
            this.readerId = readerId;
            this.daysLate = daysLate;
        }
    }

    // ====== СПИСКИ (БАЗА) ======
    static List<Book> books = new ArrayList<>();
    static List<Reader> readers = new ArrayList<>();
    static List<Loan> loans = new ArrayList<>();

    static Scanner sc = new Scanner(System.in);

    // ====== БАС БАҒДАРЛАМА ======
    public static void main(String[] args) {

        loadAll(); // Программа ашылғанда файлдан жүктеу

        while (true) {
            System.out.println("\n===== КІТАПХАНА ЖҮЙЕСІ =====");
            System.out.println("1. Кітап қосу");
            System.out.println("2. Оқырман қосу");
            System.out.println("3. Кітап беру");
            System.out.println("4. Кітап қайтару (айыппұл)");
            System.out.println("5. Тізімдерді көру");
            System.out.println("0. Шығу");
            System.out.print("Таңдау: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> addBook();
                case 2 -> addReader();
                case 3 -> issueBook();
                case 4 -> returnBook();
                case 5 -> showAll();
                case 0 -> {
                    saveAll(); // Программа жабылғанда файлға сақтау
                    System.out.println("Бағдарлама жабылды.");
                    return;
                }
                default -> System.out.println("Қате таңдау!");
            }
        }
    }

    // ====== ФУНКЦИЯЛАР ======
    static void addBook() {
        System.out.print("Кітап атауы: ");
        String title = sc.nextLine();
        int id = books.size() + 1;
        books.add(new Book(id, title));
        saveBooks();
        System.out.println("Кітап қосылды!");
    }

    static void addReader() {
        System.out.print("Оқырман аты: ");
        String name = sc.nextLine();
        int id = readers.size() + 1;
        readers.add(new Reader(id, name));
        saveReaders();
        System.out.println("Оқырман қосылды!");
    }

    static void issueBook() {
        System.out.print("Кітап ID: ");
        int bookId = sc.nextInt();
        System.out.print("Оқырман ID: ");
        int readerId = sc.nextInt();
        loans.add(new Loan(bookId, readerId, 0));
        saveLoans();
        System.out.println("Кітап берілді!");
    }

    static void returnBook() {
        System.out.print("Қай кітаптың ID? ");
        int id = sc.nextInt();

        for (Loan loan : loans) {
            if (loan.bookId == id) {
                System.out.print("Қанша күн кешікті? ");
                int days = sc.nextInt();
                loan.daysLate = days;

                int fine = calculateFine(days);
                System.out.println("Айыппұл: " + fine + " тг");

                loans.remove(loan);
                saveLoans();
                return;
            }
        }
        System.out.println("Бұл кітап берілмеген!");
    }

    static int calculateFine(int days) {
        if (days <= 0) return 0;
        if (days == 1) return 500;
        return 500 + (days - 1) * 1000;
    }

    static void showAll() {
        System.out.println("\n--- Кітаптар:");
        for (Book b : books)
            System.out.println(b.id + ". " + b.title);

        System.out.println("\n--- Оқырмандар:");
        for (Reader r : readers)
            System.out.println(r.id + ". " + r.name);

        System.out.println("\n--- Берілген кітаптар:");
        for (Loan l : loans)
            System.out.println("Кітап ID: " + l.bookId + " → Оқырман ID: " + l.readerId);
    }

    // ====== ФАЙЛМЕН ЖҰМЫС ======
    static void saveBooks() {
        try (PrintWriter pw = new PrintWriter("books.txt")) {
            for (Book b : books)
                pw.println(b.id + ";" + b.title);
        } catch (Exception e) { e.printStackTrace(); }
    }

    static void saveReaders() {
        try (PrintWriter pw = new PrintWriter("readers.txt")) {
            for (Reader r : readers)
                pw.println(r.id + ";" + r.name);
        } catch (Exception e) { e.printStackTrace(); }
    }

    static void saveLoans() {
        try (PrintWriter pw = new PrintWriter("loans.txt")) {
            for (Loan l : loans)
                pw.println(l.bookId + ";" + l.readerId + ";" + l.daysLate);
        } catch (Exception e) { e.printStackTrace(); }
    }

    static void saveAll() {
        saveBooks();
        saveReaders();
        saveLoans();
    }

    static void loadAll() {
        loadBooks();
        loadReaders();
        loadLoans();
    }

    static void loadBooks() {
        try (Scanner file = new Scanner(new File("books.txt"))) {
            while (file.hasNextLine()) {
                String[] p = file.nextLine().split(";");
                books.add(new Book(Integer.parseInt(p[0]), p[1]));
            }
        } catch (Exception ignored) {}
    }

    static void loadReaders() {
        try (Scanner file = new Scanner(new File("readers.txt"))) {
            while (file.hasNextLine()) {
                String[] p = file.nextLine().split(";");
                readers.add(new Reader(Integer.parseInt(p[0]), p[1]));
            }
        } catch (Exception ignored) {}
    }

    static void loadLoans() {
        try (Scanner file = new Scanner(new File("loans.txt"))) {
            while (file.hasNextLine()) {
                String[] p = file.nextLine().split(";");
                loans.add(new Loan(
                        Integer.parseInt(p[0]),
                        Integer.parseInt(p[1]),
                        Integer.parseInt(p[2])
                ));
            }
        } catch (Exception ignored) {}
    }
}
