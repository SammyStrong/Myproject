import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;

public class BookWindow extends JFrame {

    Database db = new Database();
    DefaultTableModel model;

    public BookWindow() {
        setTitle("Books");
        setSize(500, 400);
        setLayout(null);

        JLabel l1 = new JLabel("Title:");
        l1.setBounds(20, 20, 50, 25);
        add(l1);

        JTextField t1 = new JTextField();
        t1.setBounds(80, 20, 150, 25);
        add(t1);

        JLabel l2 = new JLabel("Author:");
        l2.setBounds(20, 60, 60, 25);
        add(l2);

        JTextField t2 = new JTextField();
        t2.setBounds(80, 60, 150, 25);
        add(t2);

        JButton addBtn = new JButton("Add");
        addBtn.setBounds(250, 20, 80, 25);
        add(addBtn);

        JButton delBtn = new JButton("Delete");
        delBtn.setBounds(250, 60, 80, 25);
        add(delBtn);

        model = new DefaultTableModel(new String[]{"ID", "Title", "Author"}, 0);
        JTable table = new JTable(model);
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 120, 450, 200);
        add(pane);

        load();

        addBtn.addActionListener(e -> {
            db.addBook(t1.getText(), t2.getText());
            load();
        });

        delBtn.addActionListener(e -> {
            int id = Integer.parseInt(table.getValueAt(table.getSelectedRow(), 0).toString());
            db.deleteBook(id);
            load();
        });

        setVisible(true);
    }

    void load() {
        model.setRowCount(0);
        try {
            ResultSet rs = db.getBooks();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"), rs.getString("title"), rs.getString("author")
                });
            }
        } catch (Exception ignored) {}
    }
}
