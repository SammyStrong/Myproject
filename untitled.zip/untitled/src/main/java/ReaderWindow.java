import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;

public class ReaderWindow extends JFrame {

    Database db = new Database();
    DefaultTableModel model;

    public ReaderWindow() {
        setTitle("Readers");
        setSize(500, 400);
        setLayout(null);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(20, 20, 60, 25);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(80, 20, 150, 25);
        add(nameField);

        JButton addBtn = new JButton("Add");
        addBtn.setBounds(250, 20, 80, 25);
        add(addBtn);

        JButton delBtn = new JButton("Delete");
        delBtn.setBounds(250, 60, 80, 25);
        add(delBtn);

        model = new DefaultTableModel(new String[]{"ID", "Name"}, 0);
        JTable table = new JTable(model);

        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 120, 450, 200);
        add(pane);

        loadReaders();

        addBtn.addActionListener(e -> {
            db.addReader(nameField.getText());
            loadReaders();
        });

        delBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select reader to delete");
                return;
            }
            int id = Integer.parseInt(table.getValueAt(row, 0).toString());
            db.deleteReader(id);
            loadReaders();
        });

        setVisible(true);
    }

    private void loadReaders() {
        model.setRowCount(0);

        try {
            ResultSet rs = db.getReaders();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
